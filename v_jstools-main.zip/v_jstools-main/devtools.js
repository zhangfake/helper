chrome.devtools.panels.create(
  'v_opitons',
  null,
  'options.html'
);

chrome.devtools.panels.create(
  'v_diff',
  null,
  'diff_text.html'
);

chrome.devtools.panels.create(
  'v_ast',
  null,
  'astexplorer_babel.html'
);